# APK Builder ProGuard Rules
-keep class com.apkbuilder.app.** { *; }
-keep class androidx.webkit.** { *; }
-dontwarn android.webkit.**
